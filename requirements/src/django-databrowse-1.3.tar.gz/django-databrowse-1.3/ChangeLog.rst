1.3 2013-11-30
==============
----

* Fix pagination
* Add many unit-tests

1.2 2013-06-10
==============
----

* Feature #11: Testing with sTravis-ci
* Fix OneToOneField support and then Model Inheritance

1.1 2013-02-21
==============
----

* Added ChangeLog.
* Fixed #1: i18n in templates.
* Fixed #3: Transifex for translation.
* Added locale file, and ready to translate.
* Fixed #9: A bug in ordering template tags, and sites.py.
* Fixed #8: Added Pagination.
