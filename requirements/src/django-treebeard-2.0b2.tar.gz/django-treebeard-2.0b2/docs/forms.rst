Forms
=====

.. module:: treebeard.forms

.. autoclass:: MoveNodeForm
   :show-inheritance:

    Read the `Django Form objects documentation`_ for reference.


    .. _`Django Form objects documentation`:
       http://docs.djangoproject.com/en/dev/topics/forms/#form-objects

