Admin
=====

.. module:: treebeard.admin


.. autoclass:: TreeAdmin
   :show-inheritance:

   To be used by Django's admin.site.register
