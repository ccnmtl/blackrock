Exceptions
==========

.. module:: treebeard.exceptions

.. autoexception:: InvalidPosition

.. autoexception:: InvalidMoveToDescendant

.. autoexception:: PathOverflow

.. autoexception:: MissingNodeOrderBy
