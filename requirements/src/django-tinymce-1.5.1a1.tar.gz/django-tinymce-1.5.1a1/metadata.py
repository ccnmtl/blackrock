name = 'tinymce'
authors = 'Joost Cassee'
version = '1.5.1a1'
release = version
