from django.db import models

class TestPage(models.Model):
    content1 = models.TextField()
    content2 = models.TextField()
