Copy the 'tiny_mce' directory from the TinyMC distribution into the
'media/js' directory. Then run './manage.py syncdb' and './manage.py runserver'
to test the TinyMCE widget.
