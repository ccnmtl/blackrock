# No body have right to leave a file complete empty.
# At least 2 lines of comment would be great
