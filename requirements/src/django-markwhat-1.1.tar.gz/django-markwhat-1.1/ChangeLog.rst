1.1 2014-01-19
===============
----

* Added ChangeLog.rst
* Fixed #2: Removing backward compatibility, From markup.py.
* Fixed #1: Re-Indention and Re-Style the code regards to pep8.
* Fixed #7: Testing on travis-ci - https://travis-ci.org/Alir3z4/django-markwhat
